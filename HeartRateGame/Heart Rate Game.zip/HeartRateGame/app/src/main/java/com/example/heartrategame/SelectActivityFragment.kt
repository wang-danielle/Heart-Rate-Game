package com.example.heartrategame

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class SelectActivityFragment : Fragment() {

    companion object {
        fun newInstance() = SelectActivityFragment()
    }

    private lateinit var viewModel: SelectActivityViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel = ViewModelProvider(this).get(SelectActivityViewModel::class.java)
        return inflater.inflate(R.layout.fragment_select_activity, container, false)
    }
}