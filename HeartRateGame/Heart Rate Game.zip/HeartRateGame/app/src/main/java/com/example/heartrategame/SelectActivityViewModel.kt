package com.example.heartrategame

import androidx.lifecycle.ViewModel

class SelectActivityViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}